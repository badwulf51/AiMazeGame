/**
 * 
 */
/**
 * @author c-raf
 *
 */
module AiMazeGame {
	requires java.datatransfer;
	requires java.desktop;
	requires jFuzzyLogic;

}